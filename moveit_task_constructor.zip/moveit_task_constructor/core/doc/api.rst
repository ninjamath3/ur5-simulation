.. _sec-api:

API reference
-------------

`C++ <_static/index.html>`_
^^^^^^^^^^^^^^^^^^^^^^^^^^^

Python
^^^^^^

.. autosummary::
   :toctree: _autosummary
   :caption: API
   :recursive:
   :template: custom-module-template.rst

   moveit.task_constructor
   pymoveit_mtc.core
   pymoveit_mtc.stages
